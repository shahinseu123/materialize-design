$(document).ready(function(){

	// Scroll to Up
	$.scrollUp();

});